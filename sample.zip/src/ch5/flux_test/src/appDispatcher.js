import {Dispatcher} from 'flux'

// Dispatcherの生成
export const appDispatcher = new Dispatcher()
