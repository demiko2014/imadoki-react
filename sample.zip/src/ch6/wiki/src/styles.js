const styles = {
  show: {
    border: '1px solid gray',
    padding: 12
  },
  edit: {
    padding: 12,
    backgroundColor: 'silver'
  },
  right: {
    textAlign: 'right'
  }
}
export default styles
