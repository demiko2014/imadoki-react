"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// 関数を定義
function kakezan(a, b) {
  return a * b;
}
// kakezanをデフォルトで公開
exports.default = kakezan;