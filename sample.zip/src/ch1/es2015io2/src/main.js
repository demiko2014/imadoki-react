// kakezanモジュールを取り込む
import kakezan from './kakezan';
// kakezan関数を利用
const v = kakezan(2, 3);
console.log(v);

