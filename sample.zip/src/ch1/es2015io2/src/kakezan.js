// 関数を定義
function kakezan(a, b) {
  return a * b;
}
// kakezanをデフォルトで公開
export default kakezan;

