"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.add = add;
exports.mul = mul;
// 外部に公開する関数を定義
function add(a, b) {
  return a + b;
}
function mul(a, b) {
  return a * b;
}