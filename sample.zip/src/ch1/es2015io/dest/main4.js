'use strict';

require('./calctest.js');

console.log(calctest.mul(2, 3));