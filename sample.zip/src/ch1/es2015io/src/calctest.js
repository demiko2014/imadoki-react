// 外部に公開する関数を定義
export function add (a, b) {
  return a + b
}
export function mul (a, b) {
  return a * b
}
