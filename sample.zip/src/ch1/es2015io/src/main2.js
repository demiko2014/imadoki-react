// モジュールを取り込む
import * as ct from './calctest.js'

// モジュールの関数を使う
console.log(ct.add(2, 3))
console.log(ct.mul(6, 8))
