// モジュールを取り込む
import {add as addF, mul as mulF} from './calctest.js'

// モジュールの関数を使う
console.log(addF(2, 3))
console.log(mulF(6, 8))
