'use strict'

// アロー演算子を利用したサンプル
var x3 = function x3 (n) {
  return n * 3
}
