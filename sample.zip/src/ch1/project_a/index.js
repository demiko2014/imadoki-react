const colors = require('colors');

const s1 = "A time to throw stones away";
const s2 = "and a time to gather stones together";
const s3 = "A time to search and a time to give up as lost";
const s4 = "A time to keep and a time to throw away";

console.log(s1.underline.red);
console.log(s2.inverse.blue);
console.log(s3.rainbow);
console.log(s4.inverse.red);

