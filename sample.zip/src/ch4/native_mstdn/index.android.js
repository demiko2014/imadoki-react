import { AppRegistry } from 'react-native'
import MastodonClient from './MastodonClient.js'
AppRegistry.registerComponent('native_mstdn', () => MastodonClient)
