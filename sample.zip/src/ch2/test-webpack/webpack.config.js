module.exports = {
  entry: './main.js',
  output: {
    filename: 'out/test.js'
  }
};

