// calc.js
export function mul (a, b) {
  return a * b
}
