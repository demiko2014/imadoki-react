import {mul} from './calc'
const a = mul(3, 5)
console.log(a)
