// 取り込まれるJavaScript
ReactDOM.render(
  <h1>Hello, World!</h1>,
  document.getElementById("root")
)
