import React, { Component } from 'react'
import './App.css'

class App extends Component {
  render () {
    return <div className='App'>
      <h2>塔を建てる時は、まず座って費用を計算しよう</h2>
    </div>
  }
}

export default App
