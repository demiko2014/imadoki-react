import React from 'react'
import ReactDOM from 'react-dom'
import InchToCm from './InchToCm'

ReactDOM.render(
  <div><InchToCm /></div>,
  document.getElementById('root')
)
